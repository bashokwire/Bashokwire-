package com.bashokwire.app

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var root: LinearLayout
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        scroll.addView(root)
        setContentView(scroll)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        render()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun render() {
        root.removeAllViews()
        when {
            !store.registered -> showRegister()
            !unlocked -> showLogin()
            else -> showMain()
        }
    }

    // ---------- Petits outils d'affichage ----------
    private fun tv(s: String, size: Float = 16f, bold: Boolean = false) =
        TextView(this).apply {
            this.text = s
            this.textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 16, 0, 8)
        }

    private fun btn(label: String, onClick: () -> Unit) =
        Button(this).apply {
            this.text = label
            setOnClickListener { onClick() }
        }

    private fun field(hint: String, type: Int = InputType.TYPE_CLASS_TEXT) =
        EditText(this).apply {
            this.hint = hint
            this.inputType = type
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- Écran 1 : inscription ----------
    private fun showRegister() {
        root.addView(tv("Bienvenue sur Bashokwire", 24f, true))
        root.addView(tv("Identifie-toi pour protéger ton téléphone."))

        val nom = field("Nom")
        val postnom = field("Postnom")
        val code = field("Code du pays (ex. +243)", InputType.TYPE_CLASS_PHONE)
        code.setText("+243")
        val pw = field(
            "Mot de passe (8 caractères : lettres, chiffres, symboles)",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        root.addView(nom)
        root.addView(postnom)
        root.addView(code)
        root.addView(pw)

        root.addView(btn("Créer mon compte") {
            val n = nom.text.toString().trim()
            val pn = postnom.text.toString().trim()
            val c = code.text.toString().trim()
            val p = pw.text.toString()
            when {
                n.isEmpty() || pn.isEmpty() -> toast("Écris ton nom et ton postnom.")
                !Regex("^\\+\\d{1,4}$").matches(c) -> toast("Code du pays invalide (ex. +243).")
                !Store.passwordOk(p) -> toast(
                    "Mot de passe trop faible : 8 caractères minimum avec lettres, chiffres et symboles."
                )
                else -> {
                    store.nom = n
                    store.postnom = pn
                    store.codePays = c
                    store.setPassword(p)
                    unlocked = true
                    render()
                }
            }
        })
        root.addView(tv("La vérification par SMS et le compte en ligne arriveront dans une prochaine version.", 13f))
    }

    // ---------- Écran 2 : ouverture protégée ----------
    private fun showLogin() {
        root.addView(tv("Bashokwire", 26f, true))
        root.addView(tv("Bonjour ${store.nom}. Entre ton mot de passe."))
        val pw = field(
            "Mot de passe",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        root.addView(pw)
        root.addView(btn("Ouvrir") {
            if (store.checkPassword(pw.text.toString())) {
                unlocked = true
                render()
            } else {
                toast("Mot de passe incorrect.")
            }
        })
    }

    // ---------- Écran 3 : accueil ----------
    private fun showMain() {
        root.addView(tv("Bashokwire", 26f, true))
        root.addView(tv("${store.nom} ${store.postnom} (${store.codePays})"))

        val rm = getSystemService(RoleManager::class.java)
        val active = rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        root.addView(tv(if (active) "Protection ACTIVE" else "Protection INACTIVE", 20f, true))
        if (!active) {
            root.addView(btn("Activer la protection") {
                startActivityForResult(
                    rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 1
                )
            })
        }

        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            root.addView(btn("Autoriser l'accès à mes contacts") {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2)
            })
        }

        // Réglage du mode
        val silence = store.mode != "reject"
        root.addView(tv(
            if (silence) "Appels inconnus : SILENCIEUX (ils ne sonnent pas)"
            else "Appels inconnus : REFUSÉS", 16f, true
        ))
        root.addView(btn(
            if (silence) "Passer en mode REFUSER" else "Passer en mode SILENCIEUX"
        ) {
            store.mode = if (silence) "reject" else "silence"
            render()
        })

        // Ajout de numéros
        root.addView(tv("Gérer les numéros", 18f, true))
        val num = field("Numéro (ex. +243812345678)", InputType.TYPE_CLASS_PHONE)
        root.addView(num)
        root.addView(btn("Ajouter aux numéros de confiance") {
            val n = num.text.toString().trim()
            if (Store.key(n).isNotEmpty()) { store.addTrusted(n); render() }
            else toast("Numéro invalide.")
        })
        root.addView(btn("Bloquer ce numéro") {
            val n = num.text.toString().trim()
            if (Store.key(n).isNotEmpty()) { store.addBlocked(n); render() }
            else toast("Numéro invalide.")
        })

        root.addView(tv("Numéros de confiance (touche pour retirer)", 16f, true))
        store.trusted().forEach { n ->
            root.addView(btn(n) { store.removeTrusted(n); render() })
        }
        root.addView(tv("Numéros bloqués (touche pour retirer)", 16f, true))
        store.blocked().forEach { n ->
            root.addView(btn(n) { store.removeBlocked(n); render() })
        }

        // Journal
        root.addView(tv("Journal des appels filtrés", 18f, true))
        val lines = store.logLines().takeLast(20).reversed()
        if (lines.isEmpty()) root.addView(tv("Aucun appel pour le moment.", 14f))
        lines.forEach { root.addView(tv(it, 14f)) }

        root.addView(btn("Verrouiller l'application") {
            unlocked = false
            render()
        })
    }
}
