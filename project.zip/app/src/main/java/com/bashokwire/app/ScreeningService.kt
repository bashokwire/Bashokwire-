package com.bashokwire.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService

/** Décide, pour chaque appel entrant, s'il sonne, est silencieux ou est refusé. */
class ScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        // On ne touche jamais aux appels sortants.
        if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val store = Store(this)
        val number = callDetails.handle?.schemeSpecificPart ?: ""

        // Tant que le compte n'est pas créé, Bashokwire laisse tout passer.
        val decision = if (!store.registered) "autorisé" else decide(store, number)

        val response = CallResponse.Builder()
        when (decision) {
            "refusé" -> response
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(false)
            "silencieux" -> response.setSilenceCall(true)
            else -> Unit
        }
        respondToCall(callDetails, response.build())
        store.log(number, decision)
    }

    private fun decide(store: Store, number: String): String {
        if (store.isBlocked(number)) return "refusé"
        if (store.isTrusted(number) || isContact(number)) return "autorisé"
        // Numéro inconnu ou masqué : selon le réglage de l'utilisateur.
        return if (store.mode == "reject") "refusé" else "silencieux"
    }

    private fun isContact(number: String): Boolean {
        if (number.isBlank()) return false
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) return false

        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(number)
        )
        return try {
            contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null, null, null
            )?.use { it.count > 0 } ?: false
        } catch (e: Exception) {
            false
        }
    }
}
