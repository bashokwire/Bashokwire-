package com.bashokwire.app

import android.content.Context
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Stockage local (sur le téléphone seulement) : compte, listes, réglages, journal. */
class Store(context: Context) {

    private val p = context.applicationContext
        .getSharedPreferences("bashokwire", Context.MODE_PRIVATE)

    // ---------- Compte ----------
    var nom: String
        get() = p.getString("nom", "") ?: ""
        set(v) { p.edit().putString("nom", v).apply() }

    var postnom: String
        get() = p.getString("postnom", "") ?: ""
        set(v) { p.edit().putString("postnom", v).apply() }

    var codePays: String
        get() = p.getString("codePays", "") ?: ""
        set(v) { p.edit().putString("codePays", v).apply() }

    val registered: Boolean
        get() = p.contains("hash")

    fun setPassword(pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("salt", hex(salt))
            .putString("hash", hash(pw, salt))
            .apply()
    }

    fun checkPassword(pw: String): Boolean {
        val saltHex = p.getString("salt", null) ?: return false
        val expected = p.getString("hash", null) ?: return false
        val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        return hash(pw, salt) == expected
    }

    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 100_000, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return hex(factory.generateSecret(spec).encoded)
    }

    private fun hex(bytes: ByteArray): String =
        bytes.joinToString("") { "%02x".format(it) }

    // ---------- Réglages ----------
    /** "silence" : l'appel inconnu ne sonne pas. "reject" : l'appel inconnu est refusé. */
    var mode: String
        get() = p.getString("mode", "silence") ?: "silence"
        set(v) { p.edit().putString("mode", v).apply() }

    // ---------- Listes ----------
    fun trusted(): List<String> = list("trusted")
    fun blocked(): List<String> = list("blocked")

    fun addTrusted(n: String) = add("trusted", n)
    fun addBlocked(n: String) = add("blocked", n)
    fun removeTrusted(n: String) = remove("trusted", n)
    fun removeBlocked(n: String) = remove("blocked", n)

    fun isTrusted(number: String) = contains("trusted", number)
    fun isBlocked(number: String) = contains("blocked", number)

    private fun list(name: String): List<String> =
        (p.getStringSet(name, emptySet()) ?: emptySet()).sorted()

    private fun add(name: String, n: String) {
        val s = HashSet(p.getStringSet(name, emptySet()) ?: emptySet())
        s.add(n)
        p.edit().putStringSet(name, s).apply()
    }

    private fun remove(name: String, n: String) {
        val s = HashSet(p.getStringSet(name, emptySet()) ?: emptySet())
        s.remove(n)
        p.edit().putStringSet(name, s).apply()
    }

    private fun contains(name: String, number: String): Boolean {
        val k = key(number)
        if (k.isEmpty()) return false
        return list(name).any { key(it) == k }
    }

    // ---------- Journal ----------
    fun log(number: String, decision: String) {
        val shown = if (number.isBlank()) "numéro masqué" else number
        val time = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date())
        val lines = logLines().toMutableList()
        lines.add("$time | $shown | $decision")
        val kept = lines.takeLast(100)
        p.edit().putString("log", kept.joinToString("\n")).apply()
    }

    fun logLines(): List<String> {
        val raw = p.getString("log", "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split("\n")
    }

    companion object {
        /** Compare deux numéros par leurs 9 derniers chiffres. */
        fun key(number: String): String = number.filter { it.isDigit() }.takeLast(9)

        /** Au moins 8 caractères, avec une lettre, un chiffre et un symbole. */
        fun passwordOk(pw: String): Boolean =
            pw.length >= 8 &&
                pw.any { it.isLetter() } &&
                pw.any { it.isDigit() } &&
                pw.any { !it.isLetterOrDigit() }
    }
}
